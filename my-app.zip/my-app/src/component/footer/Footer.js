import React from 'react';
import Menu from '../../component/menu';
import PropTypes from 'prop-types';

const propTypes = {
  children: PropTypes.node,
};
const defaultProps = {
  children: undefined,
};

export const Footer = (props) => {
  const { name, age, address } = props;

  const addClickHandle = () => {
    const { addHandle } = props;
    addHandle();
  }

  return (
    <div>
    <input type="button" value="add" onClick={addClickHandle} />
      Footer
      <h1>Name: {name}</h1>
      <h1>Age: {age}</h1>
      <h1>Address: {address}</h1>
      <Menu />
    </div>
  );
};

Footer.propTypes = propTypes;
Footer.defaultProps = defaultProps;
export default Footer;
