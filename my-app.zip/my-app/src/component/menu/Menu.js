import './menu.css';

const Menu = () => {
  return(
  <div className="menu-container">
    <ul>
    <li><a href="#">Home</a></li>
    <li><a href="#">About Us</a></li>
    <li><a href="#">Contact</a></li>
    </ul>
  </div>
  );
}
export default Menu;
