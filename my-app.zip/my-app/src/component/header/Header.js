import Menu from '../../component/menu';
import './Header.css';

function Header() {
  return (
    <div className="header">
    <div className="logo">Logo</div>
    <Menu />
    </div>
  );
}

export default Header;
